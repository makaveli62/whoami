from django.apps import AppConfig


class SafetyConfig(AppConfig):
    name = 'safety'
