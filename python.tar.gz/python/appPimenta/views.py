from django.shortcuts import render, redirect
from appPimenta.models import Clientes
from appPimenta.form import ClientesForm

# Create your views here.




def home(request):
    data = {}
#    data['db'] = Clientes.objects.all()
    data['makaveli'] = 'theDon'
    return render(request, 'index.html', data)


def clientest(request):
    data = {}
    data['db'] = Clientes.objects.all()
    return render(request, 'clientest.html', data)

def clientesf(request):
    data = {}
    data['form'] = ClientesForm

    return render(request, 'clientesf.html', data)


def create(request):
    form = ClientesForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')

def view(request, pk):
    data = {}
    data['db'] = Clientes.objects.get(clienteId=pk)

    return render(request, 'view.html', data)

def edit(request, pk):
    data = {}
    data['db'] = Clientes.objects.get(clienteId=pk)
    data['form'] = ClientesForm(instance=data['db'])

    return render(request, 'clientesf.html', data)


def update(request, pk,):
    data = {}
    data['db'] = Clientes.objects.get(clienteId=pk)
    form = ClientesForm(request.POST or None, instance=data['db'])
    if form.is_valid():
        form.save()
        return redirect('home')



def delete(request, pk):

    db = Clientes.objects.get(clienteId=pk)
    db.delete()
    return redirect('home')

def imp(request):
    data = {}
    data['db'] = Clientes.objects.all()
    return render(request, 'imp.html', data)


