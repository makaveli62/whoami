from django.db import models

from django.db import models

class Clientes(models.Model):
    clienteId = models.IntegerField(primary_key='true')
    nome = models.CharField(max_length=120)
    idade = models.CharField(max_length=7)
    sexo = models.CharField(max_length=9)
    email = models.EmailField(max_length=80)
    contato = models.CharField(max_length=12)
    cep = models.CharField(max_length=12)


    

