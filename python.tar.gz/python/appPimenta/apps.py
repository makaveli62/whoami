from django.apps import AppConfig


class ApppimentaConfig(AppConfig):
    name = 'appPimenta'
