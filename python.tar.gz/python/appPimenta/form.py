from django.forms import ModelForm
from appPimenta.models import Clientes




class ClientesForm(ModelForm):
    class Meta:
        model = Clientes
        fields = {'clienteId','nome', 'idade', 'sexo', 'email', 'contato', 'cep'}